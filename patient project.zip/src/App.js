import React from 'react';
import './App.css';
import addPatient from './layouts/AddPatient.js'
import AllPatient from './layouts/AllPatient.js'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import AddPatient from './layouts/AddPatient.js';
import AboutUs from './layouts/AboutUs';
function App() {
  const styles={
    brandName:{
      fontFamily:"Nunito",
      fontWeight:"Regular",
      fontSize:32,
      cursor:"pointer"

    },
    links:{
      fontFamily:"Nunito",
      fontWeight:"Light",
      fontSize:24,
      cursor:"pointer"
    }
  }
  return (
    <Router>
    <div className="fluid-container mt-5">
      <div className="row">
        <div className="col-md-12">
          <div className="row">
            <div style={styles.brandName} className="offset-md-1 col-md-4">
            <Link to="/"><img className="mr-3" style={{marginTop:"-15px"}}/>
              Patient FHIR</Link>
            </div>
            <div style={styles.links} className="col-md-2 offset-md-1">
              <Link to="/">Liste des patients</Link>
            </div>
            <div style={styles.links} className="col-md-2">
              <Link to="/addpatient">Ajouter patient</Link>
            </div>
            <div style={styles.links} className="col-md-2">
              <Link to="/aboutUs">A propos</Link>
            </div>
          </div>
        </div>
        
        <div style={{marginTop:"200px"}} className="col-md-12 ">
        <Switch>
          <Route exact path="/">
            <AllPatient />
          </Route>
          <Route exact path="/addpatient">
            <AddPatient/>
          </Route>
          <Route exact path="/aboutUs">
            <AboutUs/>
          </Route>
        </Switch>
        </div>
      </div>
      <footer id="sticky-footer" class="mt-5 py-4 bg-dark text-white-50">
              <div class="container text-center">
               &copy; 2019/2020 All right reserved to M.ABDELLI & M.TALEB
              </div>
            </footer>
    </div>
    
    </Router>
  );
}

export default App;
