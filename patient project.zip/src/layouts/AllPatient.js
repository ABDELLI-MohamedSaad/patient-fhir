import React, { Component } from 'react';
import Patient from './patient.js'
import axios from 'axios'
import patient from './patient.js';
class AllPatient extends Component {

  constructor(props){
    super(props)
    this.state={
      patients:[]
    }
  }
  
  componentDidMount() {
    axios.get(`http://hapi.fhir.org/baseR4/Patient?_count=30`)
      .then(res => {
        const patients = res.data.entry;
        this.setState({ patients });
        console.log(patients)
      })
  }
  delete(id){
    axios.delete("http://hapi.fhir.org/baseR4/Patient/"+id+"?&_cascade=delete")
    .then(res => {
      console.log(res);
      console.log(res.data);
      window.location.reload(true);

    })
    
  }
  render() {
    return (
      <div className="row">
        <div className="col-md-12 mb-3 text-center"><h1>La liste des patients</h1></div>
        <div className="offset-md-2 col-md-8">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Nom</th>
              <th scope="col">Sexe</th>
              <th scope="col">Date de naissance</th>
              <th scope="col" colSpan="2" className="text-center">Operation</th>
            </tr>
          </thead>
          <tbody>
            {this.state.patients.map(patient=>
                  <Patient key={patient} patientData={patient} handleClick={this.delete} />
            )}
          </tbody>
        </table>
      </div> 
      </div>
      
    );
  }
}

export default AllPatient;