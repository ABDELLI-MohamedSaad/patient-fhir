import React, { Component } from 'react';

class AboutUs extends Component {

  constructor(props){
    super(props)
    
  }
  
  
  render() {
    return (
      <div className="row">
        <div className="offset-md-2 col-md-8 offset-md-2 text-center" style={{fontSize:22}}>
        Cette application a pour objectif d'effectuer la gestion des patients (ajout, modification, suppression) via un serveur FHIR public, développée en REACT  par M. ABDELLI & M. TALEB .
        <div> Contactez-nous:
        <br/>

        - abdelli.saad@gmail.com
        <br/>
        - aminetaleb00@gmail.com</div>
       
        </div>
      </div>
      
    );
  }
}

export default AboutUs;