import React, { Component } from 'react';
import { Button,Modal} from 'react-bootstrap';
import axios from 'axios'
class patient extends Component {

  constructor(props){
    super(props)
    this.state={
        name:'',
        gender:'',
        Birthday:'',
        id:'',
        setShow:false,
    }
  }
  componentWillMount(){
    let name="deleted"
    if(this.props.patientData.resource.name){
        name=this.props.patientData.resource.name[0].family;
    }
    let id=this.props.patientData.resource.id;
    let gender="aucun type de sexe est enregistre";
    if(this.props.patientData.resource.gender){ gender=this.props.patientData.resource.gender}
    let birthDate="aucune date de naissance est enregistre";
    if(this.props.patientData.resource.birthDate){birthDate=this.props.patientData.resource.birthDate}
    this.setState({name,id,gender,birthDate,id})
  }
  handleModify=()=>{
    var name=[];
    let family=this.state.name;
    name.push({family});
    let resourceType="Patient";
    let id=this.state.id;
    let gender=this.state.gender;
    let birthDate=this.state.birthDate;
    let data={
        resourceType,id,name,gender,birthDate
    }
    axios.put("http://hapi.fhir.org/baseR4/Patient/"+id, { ...data })
    .then(res => {
      console.log(res);
      console.log(res.data);
      
    })
}

  changeName=(e)=>{
    let namee=e.target.value;
    this.setState({name:namee})
  }
  changeBirthdate=(e)=>{
    this.setState({birthDate:e.target.value})
  }
  changeGender=(e)=>{
    this.setState({gender:e.target.value})
  }

  render() {
    return (
        <>
        <tr>
            <td >{this.state.name}</td>
            <td >{this.state.gender}</td>
            <td >{this.state.birthDate}</td>
            <td >
                <button class="btn btn-primary"  onClick={()=> this.setState({setShow:true})}>Modfier</button>
            </td>
            <td>
                <button  class="btn btn-danger" onClick={()=>this.props.handleClick(this.state.id)}>Supprimer</button>
            </td>
        </tr>
            <Modal show={this.state.setShow} onHide={()=> this.setState({setShow:false})}>
                <Modal.Header closeButton>
                <Modal.Title>Modifier patient</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                <div className="offset-md-2 col-md-6">
                    <div className="form-group">
                    <label for="exampleInputEmail1">Nom</label>
                    <input type="text" value={this.state.name} onChange={this.changeName} className="form-control" id="name"  placeholder="Enter your name"/>
                    </div>
                    <div className="form-group">
                    <label for="exampleInputEmail1">Sexe(male/female)</label>
                    <input type="text" value={this.state.gender} className="form-control" onChange={this.changeGender} id="gender"  placeholder="Enter your gender"/>
                    </div>
                    <div className="form-group">
                    <label for="exampleInputEmail1">Date de naissance</label>
                    <input type="text" value={this.state.birthDate} className="form-control" onChange={this.changeBirthdate} id="birthdate" placeholder="yyyy-mm-dd"/>
                    </div>
                </div>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="secondary" onClick={()=> this.setState({setShow:false})}>
                    Fermer
                </Button>
                <Button variant="primary" onClick={this.handleModify}>
                    Enregistrer les changements
                </Button>
                </Modal.Footer>
            </Modal>
            </>
      
    );
  }
}

export default patient;