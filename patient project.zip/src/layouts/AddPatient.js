import React, { Component } from 'react';
import axios from 'axios';

class AddPatient extends Component {
  constructor(props){
    super(props);
    this.state={
      resourceType: "Patient",
      name:[],
      gender:'',
      birthDate:'',
      succes:0
    }
  }
  componentWillMount(){
  }
  sumbitData=()=>{
    const data = this.state;
    console.log(data);
    axios.post(`http://hapi.fhir.org/baseR4/Patient`, { ...data })
    .then(res => {
      this.setState({succes:1})
      console.log(res);
      console.log(res.data);
      
    })
  }
  changeName=(e)=>{
    var namee=[];
    let family=e.target.value;
    namee.push({family});
    console.log(namee)
    this.setState({name:namee})
  }
  changeBirthdate=(e)=>{
    this.setState({birthDate:e.target.value})
  }
  changeGender=(e)=>{
    this.setState({gender:e.target.value})
  }
  render() {
    return (
      <div className="row">
                <div className="col-md-12 mb-3 text-center"><h1>Ajouter patient</h1></div>
          {this.state.succes===1 &&
            <div className="offset-md-2 col-md-6 alert alert-success">Le patient a �t� bien ajout�</div>
          }
          <div className="offset-md-2 col-md-8">
            <div className="form-group">
              <label for="exampleInputEmail1">Nom</label>
              <input type="text" onChange={this.changeName} className="form-control" id="name"  placeholder="Entrer le nom du patient"/>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Sexe(male/female)</label>
              <input type="text" className="form-control" onChange={this.changeGender} id="gender"  placeholder="Enter le sexe du patient"/>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Date de naissance</label>
              <input type="text" className="form-control" onChange={this.changeBirthdate} id="birthdate" placeholder="yyyy-mm-dd"/>
            </div>
            <button onClick={this.sumbitData} class="btn btn-primary">Ajouter</button>
          </div>
      </div>
      
    );
  }
}

export default AddPatient;